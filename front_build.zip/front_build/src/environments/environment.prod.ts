export const environment = {
  production: true,
  apiUrl: "http://127.0.0.1:80"
};
