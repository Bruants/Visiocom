import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TabsRoutingModule } from './tabs-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    TabsRoutingModule
  ]
})
export class TabsModule { }
