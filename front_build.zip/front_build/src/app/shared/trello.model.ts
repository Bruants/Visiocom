export class Trello {
    username:       string;
    tokenTrello?:   string;
    board?:         string;
    list?:          string;
    card?:          string;
}
