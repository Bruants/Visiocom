export class ReturnMessage {
    message: string
}
