export class User {
    name:        string;
    firstName:   string;
    username:    string;
    password:    string;
    newPassword?: string;
    mail:        string;
    phone:       string;
}
