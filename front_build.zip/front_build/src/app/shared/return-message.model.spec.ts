import { ReturnMessage } from './return-message.model';

describe('ReturnMessage', () => {
  it('should create an instance', () => {
    expect(new ReturnMessage()).toBeTruthy();
  });
});
