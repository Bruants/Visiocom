import { Trello } from './trello.model';

describe('Trello', () => {
  it('should create an instance', () => {
    expect(new Trello()).toBeTruthy();
  });
});
